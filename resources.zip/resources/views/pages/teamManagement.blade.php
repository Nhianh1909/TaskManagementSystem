<div id="team" class="page hidden">
        <div class="max-w-6xl mx-auto px-4 py-8">
            <div class="flex justify-between items-center mb-8">
                <h1 class="text-3xl font-bold text-gray-800">Team Management</h1>
                <button onclick="openTeamModal()" class="gradient-btn text-white px-6 py-3 rounded-lg font-semibold">
                    <i class="fas fa-user-plus mr-2"></i>Add Member
                </button>
            </div>

            <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div class="card-3d bg-white rounded-2xl shadow-lg p-6 glow-effect">
                    <div class="text-center">
                        <img src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iODAiIGhlaWdodD0iODAiIHZpZXdCb3g9IjAgMCA4MCA4MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iNDAiIGN5PSI0MCIgcj0iNDAiIGZpbGw9IiMwMDdCRkYiLz4KPHN2ZyB3aWR0aD0iNTAiIGhlaWdodD0iNTAiIHZpZXdCb3g9IjAgMCA1MCA1MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4PSIxNSIgeT0iMTUiPgo8cGF0aCBkPSJNMjUgNUMzMC41MjI4IDUgMzUgOS40NzcxNSAzNSAxNUMzNSAyMC41MjI4IDMwLjUyMjggMjUgMjUgMjVDMTkuNDc3MiAyNSAxNSAyMC41MjI4IDE1IDE1QzE1IDkuNDc3MTUgMTkuNDc3MiA1IDI1IDVaIiBmaWxsPSJ3aGl0ZSIvPgo8cGF0aCBkPSJNMjUgMzBDMzMuMjg0MyAzMCA0MCAzNi43MTU3IDQwIDQ1QzQwIDUzLjI4NDMgMzMuMjg0MyA2MCAyNSA2MEMxNi43MTU3IDYwIDEwIDUzLjI4NDMgMTAgNDVDMTAgMzYuNzE1NyAxNi43MTU3IDMwIDI1IDMwWiIgZmlsbD0id2hpdGUiLz4KPC9zdmc+Cjwvc3ZnPgo=" alt="John Doe" class="w-20 h-20 rounded-full mx-auto mb-4">
                        <h3 class="text-xl font-semibold text-gray-800 mb-1">John Doe</h3>
                        <p class="text-blue-600 font-medium mb-2">Scrum Master</p>
                        <p class="text-sm text-gray-600 mb-4">Leading the team with 5+ years of Agile experience</p>
                        <div class="flex justify-center space-x-2">
                            <button class="text-blue-600 hover:text-blue-800 p-2">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="text-red-600 hover:text-red-800 p-2">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                </div>

                <div class="card-3d bg-white rounded-2xl shadow-lg p-6 glow-effect">
                    <div class="text-center">
                        <img src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iODAiIGhlaWdodD0iODAiIHZpZXdCb3g9IjAgMCA4MCA4MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iNDAiIGN5PSI0MCIgcj0iNDAiIGZpbGw9IiNGRkE1MDIiLz4KPHN2ZyB3aWR0aD0iNTAiIGhlaWdodD0iNTAiIHZpZXdCb3g9IjAgMCA1MCA1MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4PSIxNSIgeT0iMTUiPgo8cGF0aCBkPSJNMjUgNUMzMC41MjI4IDUgMzUgOS40NzcxNSAzNSAxNUMzNSAyMC41MjI4IDMwLjUyMjggMjUgMjUgMjVDMTkuNDc3MiAyNSAxNSAyMC41MjI4IDE1IDE1QzE1IDkuNDc3MTUgMTkuNDc3MiA1IDI1IDVaIiBmaWxsPSJ3aGl0ZSIvPgo8cGF0aCBkPSJNMjUgMzBDMzMuMjg0MyAzMCA0MCAzNi43MTU3IDQwIDQ1QzQwIDUzLjI4NDMgMzMuMjg0MyA2MCAyNSA2MEMxNi43MTU3IDYwIDEwIDUzLjI4NDMgMTAgNDVDMTAgMzYuNzE1NyAxNi43MTU3IDMwIDI1IDMwWiIgZmlsbD0id2hpdGUiLz4KPC9zdmc+Cjwvc3ZnPgo=" alt="Sarah Smith" class="w-20 h-20 rounded-full mx-auto mb-4">
                        <h3 class="text-xl font-semibold text-gray-800 mb-1">Sarah Smith</h3>
                        <p class="text-green-600 font-medium mb-2">Product Owner</p>
                        <p class="text-sm text-gray-600 mb-4">Defining product vision and managing backlog</p>
                        <div class="flex justify-center space-x-2">
                            <button class="text-blue-600 hover:text-blue-800 p-2">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="text-red-600 hover:text-red-800 p-2">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                </div>

                <div class="card-3d bg-white rounded-2xl shadow-lg p-6 glow-effect">
                    <div class="text-center">
                        <img src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iODAiIGhlaWdodD0iODAiIHZpZXdCb3g9IjAgMCA4MCA4MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iNDAiIGN5PSI0MCIgcj0iNDAiIGZpbGw9IiMyRUQ1NzMiLz4KPHN2ZyB3aWR0aD0iNTAiIGhlaWdodD0iNTAiIHZpZXdCb3g9IjAgMCA1MCA1MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4PSIxNSIgeT0iMTUiPgo8cGF0aCBkPSJNMjUgNUMzMC41MjI4IDUgMzUgOS40NzcxNSAzNSAxNUMzNSAyMC41MjI4IDMwLjUyMjggMjUgMjUgMjVDMTkuNDc3MiAyNSAxNSAyMC41MjI4IDE1IDE1QzE1IDkuNDc3MTUgMTkuNDc3MiA1IDI1IDVaIiBmaWxsPSJ3aGl0ZSIvPgo8cGF0aCBkPSJNMjUgMzBDMzMuMjg0MyAzMCA0MCAzNi43MTU3IDQwIDQ1QzQwIDUzLjI4NDMgMzMuMjg0MyA2MCAyNSA2MEMxNi43MTU3IDYwIDEwIDUzLjI4NDMgMTAgNDVDMTAgMzYuNzE1NyAxNi43MTU3IDMwIDI1IDMwWiIgZmlsbD0id2hpdGUiLz4KPC9zdmc+Cjwvc3ZnPgo=" alt="Mike Johnson" class="w-20 h-20 rounded-full mx-auto mb-4">
                        <h3 class="text-xl font-semibold text-gray-800 mb-1">Mike Johnson</h3>
                        <p class="text-purple-600 font-medium mb-2">Developer</p>
                        <p class="text-sm text-gray-600 mb-4">Full-stack developer specializing in React and Node.js</p>
                        <div class="flex justify-center space-x-2">
                            <button class="text-blue-600 hover:text-blue-800 p-2">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="text-red-600 hover:text-red-800 p-2">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
