<nav class="bg-white shadow-lg sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <div class="flex-shrink-0 flex items-center">
                        <i class="fas fa-rocket text-2xl text-blue-600 mr-2"></i>
                        <span class="text-xl font-bold text-gray-800">ScrumSpark</span>
                    </div>
                    <div class="hidden md:ml-6 md:flex md:space-x-8">
                        <a href="#" class="nav-link text-gray-700 hover:text-blue-600 px-3 py-2 text-sm font-medium transition-colors" onclick="showPage('dashboard')">Dashboard</a>
                        <a href="#" class="nav-link text-gray-700 hover:text-blue-600 px-3 py-2 text-sm font-medium transition-colors" onclick="showPage('taskboard')">Task Board</a>
                        <a href="#" class="nav-link text-gray-700 hover:text-blue-600 px-3 py-2 text-sm font-medium transition-colors" onclick="showPage('sprint')">Sprint Planning</a>
                        <a href="#" class="nav-link text-gray-700 hover:text-blue-600 px-3 py-2 text-sm font-medium transition-colors" onclick="showPage('team')">Team</a>
                        <a href="#" class="nav-link text-gray-700 hover:text-blue-600 px-3 py-2 text-sm font-medium transition-colors" onclick="showPage('reports')">Reports</a>
                    </div>
                </div>
                <div class="flex items-center space-x-4">
                    <button onclick="toggleDarkMode()" class="p-2 rounded-full hover:bg-gray-100 transition-colors">
                        <i class="fas fa-moon text-gray-600"></i>
                    </button>
                    <div class="relative">
                        <button class="flex items-center space-x-2 p-2 rounded-full hover:bg-gray-100 transition-colors">
                            <img src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMTYiIGN5PSIxNiIgcj0iMTYiIGZpbGw9IiMwMDdCRkYiLz4KPHN2ZyB3aWR0aD0iMjAiIGhlaWdodD0iMjAiIHZpZXdCb3g9IjAgMCAyMCAyMCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4PSI2IiB5PSI2Ij4KPHBhdGggZD0iTTEwIDJDMTEuMSAyIDEyIDIuOSAxMiA0QzEyIDUuMSAxMS4xIDYgMTAgNkM4LjkgNiA4IDUuMSA4IDRDOCAyLjkgOC45IDIgMTAgMloiIGZpbGw9IndoaXRlIi8+CjxwYXRoIGQ9Ik0xMCA4QzEzLjMxIDggMTYgMTAuNjkgMTYgMTRDMTYgMTcuMzEgMTMuMzEgMjAgMTAgMjBDNi42OSAyMCA0IDE3LjMxIDQgMTRDNCAxMC42OSA2LjY5IDggMTAgOFoiIGZpbGw9IndoaXRlIi8+Cjwvc3ZnPgo8L3N2Zz4K" alt="User Avatar" class="w-8 h-8 rounded-full">
                            <span class="text-sm font-medium text-gray-700 mobile-hidden">John Doe</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </nav>
